/**
 * 
 */
/**
 * 
 */
module FreelancerProjectTracker {
	requires java.sql;
	requires java.desktop;
}