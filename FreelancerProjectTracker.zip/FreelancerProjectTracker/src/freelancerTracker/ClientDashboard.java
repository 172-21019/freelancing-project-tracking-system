package freelancerTracker;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ClientDashboard extends JFrame {
    JTable projectTable;
    String username;
    JButton acceptButton, rejectButton, completeButton, refreshButton;

    public ClientDashboard(String username) {
        this.username = username;

        setTitle("Client Dashboard - Projects");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        projectTable = new JTable();
        JScrollPane sp = new JScrollPane(projectTable);
        add(sp, BorderLayout.CENTER);

        styleTable(projectTable); // Apply table styling

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        acceptButton = new JButton("Accept Project");
        rejectButton = new JButton("Reject Project");
        completeButton = new JButton("Mark as Completed");
        refreshButton = new JButton("Refresh");

        buttonPanel.add(acceptButton);
        buttonPanel.add(rejectButton);
        buttonPanel.add(completeButton);
        buttonPanel.add(refreshButton);

        add(buttonPanel, BorderLayout.SOUTH);

        acceptButton.addActionListener(e -> updateStatus("Accepted"));
        rejectButton.addActionListener(e -> updateStatus("Rejected"));
        completeButton.addActionListener(e -> updateStatus("Completed"));
        refreshButton.addActionListener(e -> loadProjects());
        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(e -> {
            dispose(); // Close the current frame
            new LoginPage(); // Replace with your login class
        });

        buttonPanel.add(logoutButton);

        loadProjects();

        setVisible(true);
    }

    private void loadProjects() {
        try (Connection con = DatabaseConnection.getConnection()) {
            PreparedStatement pst = con.prepareStatement(
                "SELECT id, title, description, assignedTo, status FROM projects WHERE assignedTo IS NULL OR assignedTo=?"
            );
            pst.setString(1, username);
            ResultSet rs = pst.executeQuery();

            DefaultTableModel model = new DefaultTableModel(
                new String[]{"ID", "Title", "Description", "Assigned To", "Status"}, 0
            );
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("description"),
                    rs.getString("assignedTo"),
                    rs.getString("status")
                });
            }
            projectTable.setModel(model);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void updateStatus(String newStatus) {
        int row = projectTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a project!");
            return;
        }

        int projectId = (int) projectTable.getValueAt(row, 0);

        try (Connection con = DatabaseConnection.getConnection()) {
            con.setAutoCommit(false); // Start transaction

            // Update project status
            PreparedStatement pst;
            if (newStatus.equals("Rejected")) {
                pst = con.prepareStatement("UPDATE projects SET status=?, assignedTo=NULL WHERE id=?");
                pst.setString(1, "Rejected");
                pst.setInt(2, projectId);
            } else {
                pst = con.prepareStatement("UPDATE projects SET status=?, assignedTo=? WHERE id=?");
                pst.setString(1, newStatus);
                pst.setString(2, username);
                pst.setInt(3, projectId);
            }
            pst.executeUpdate();

            // Update count_of_projects table
            if (newStatus.equals("Accepted") || newStatus.equals("Completed")) {
                PreparedStatement checkStmt = con.prepareStatement(
                    "SELECT client_name FROM count_of_projects WHERE client_name = ?"
                );
                checkStmt.setString(1, username);
                ResultSet rs = checkStmt.executeQuery();

                if (!rs.next()) {
                    // Insert new client entry
                    PreparedStatement insertStmt = con.prepareStatement(
                        "INSERT INTO count_of_projects (client_name, count_of_accepted, count_of_completed) VALUES (?, ?, ?)"
                    );
                    insertStmt.setString(1, username);
                    insertStmt.setInt(2, newStatus.equals("Accepted") ? 1 : 0);
                    insertStmt.setInt(3, newStatus.equals("Completed") ? 1 : 0);
                    insertStmt.executeUpdate();
                } else {
                    // Update existing entry
                    String columnToUpdate = newStatus.equals("Accepted") ? "count_of_accepted" : "count_of_completed";
                    PreparedStatement updateStmt = con.prepareStatement(
                        "UPDATE count_of_projects SET " + columnToUpdate + " = " + columnToUpdate + " + 1 WHERE client_name = ?"
                    );
                    updateStmt.setString(1, username);
                    updateStmt.executeUpdate();
                }
            }

            con.commit(); // Commit transaction
            JOptionPane.showMessageDialog(this, "Project " + newStatus + " successfully!");
            loadProjects();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void styleTable(JTable table) {
        table.setRowHeight(25);
        table.setFont(new Font("SansSerif", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 15));
        table.getTableHeader().setBackground(new Color(200, 200, 255));
        table.setGridColor(Color.LIGHT_GRAY);
    }
}
