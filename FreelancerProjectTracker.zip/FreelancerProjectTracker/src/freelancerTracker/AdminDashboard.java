package freelancerTracker;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminDashboard extends JFrame {
    JTable projectTable;
    JButton addProjectButton, deleteButton, refreshButton, toggleThemeButton, logoutButton;
    boolean isDarkTheme = false;

    public AdminDashboard() {
        setTitle("Admin Dashboard - Projects");
        setSize(900, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        projectTable = new JTable();
        JScrollPane sp = new JScrollPane(projectTable);
        add(sp, BorderLayout.CENTER);

        styleTable(projectTable);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        addProjectButton = new JButton("Add New Project");
        deleteButton = new JButton("Delete Project");
        refreshButton = new JButton("Refresh");
        toggleThemeButton = new JButton("Toggle Theme");
        logoutButton = new JButton("Logout");

        buttonPanel.add(addProjectButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(toggleThemeButton);
        buttonPanel.add(logoutButton);

        add(buttonPanel, BorderLayout.SOUTH);

        addProjectButton.addActionListener(e -> openAddProjectDialog());
        deleteButton.addActionListener(e -> deleteSelectedProject());
        refreshButton.addActionListener(e -> loadProjects());
        toggleThemeButton.addActionListener(e -> toggleTheme());
        logoutButton.addActionListener(e -> {
            dispose();
            new LoginPage(); // Assuming LoginPage exists
        });

        loadProjects();
        setVisible(true);
    }

    private void styleTable(JTable table) {
        table.setRowHeight(25);
        table.setFont(new Font("SansSerif", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 15));
        table.getTableHeader().setBackground(new Color(200, 200, 255));
        table.setGridColor(Color.LIGHT_GRAY);
    }

    private void toggleTheme() {
        Color bg, fg;
        if (isDarkTheme) {
            bg = Color.WHITE;
            fg = Color.BLACK;
        } else {
            bg = new Color(45, 45, 45);
            fg = Color.WHITE;
        }

        getContentPane().setBackground(bg);
        projectTable.setBackground(bg);
        projectTable.setForeground(fg);
        projectTable.getTableHeader().setBackground(isDarkTheme ? new Color(200, 200, 255) : Color.DARK_GRAY);
        projectTable.getTableHeader().setForeground(fg);
        isDarkTheme = !isDarkTheme;
    }

    private void loadProjects() {
        try (Connection con = DatabaseConnection.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT id, title, description, assignedTo, status FROM projects");

            DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Title", "Description", "Assigned To", "Status"}, 0);
            while (rs.next()) {
                String status = rs.getString("status");
                String displayStatus;
                switch (status) {
                    case "Accepted":
                        displayStatus = "Pending";
                        break;
                    case "Completed":
                        displayStatus = "Completed";
                        break;
                    default:
                        displayStatus = "Available";
                        break;
                }

                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("assignedTo"),
                        displayStatus
                });
            }
            projectTable.setModel(model);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        projectTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = projectTable.rowAtPoint(e.getPoint());
                int col = projectTable.columnAtPoint(e.getPoint());

                // Column 3 = "Assigned To"
                if (col == 3) {
                    String clientName = (String) projectTable.getValueAt(row, col);
                    if (clientName != null && !clientName.trim().isEmpty()) {
                        showClientStats(clientName);
                    }
                }
            }
        });

    }

    private void openAddProjectDialog() {
        JTextField titleField = new JTextField();
        JTextField descField = new JTextField();
        Object[] fields = {
                "Title:", titleField,
                "Description:", descField
        };

        int option = JOptionPane.showConfirmDialog(this, fields, "Add New Project", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try (Connection con = DatabaseConnection.getConnection()) {
                PreparedStatement pst = con.prepareStatement("INSERT INTO projects (title, description, status) VALUES (?, ?, 'Available')");
                pst.setString(1, titleField.getText());
                pst.setString(2, descField.getText());
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Project Added Successfully!");
                loadProjects();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    private void showClientStats(String clientName) {
        try (Connection con = DatabaseConnection.getConnection()) {
            PreparedStatement pstAccepted = con.prepareStatement(
                "SELECT COUNT(*) AS count FROM projects WHERE assignedTo = ? AND status = 'Accepted'");
            pstAccepted.setString(1, clientName);
            ResultSet rsAccepted = pstAccepted.executeQuery();
            int acceptedCount = rsAccepted.next() ? rsAccepted.getInt("count") : 0;

            PreparedStatement pstCompleted = con.prepareStatement(
                "SELECT COUNT(*) AS count FROM projects WHERE assignedTo = ? AND status = 'Completed'");
            pstCompleted.setString(1, clientName);
            ResultSet rsCompleted = pstCompleted.executeQuery();
            int completedCount = rsCompleted.next() ? rsCompleted.getInt("count") : 0;

            JOptionPane.showMessageDialog(this,
                "Client: " + clientName +
                "\nAccepted Projects: " + acceptedCount +
                "\nCompleted Projects: " + completedCount,
                "Client Stats",
                JOptionPane.INFORMATION_MESSAGE
            );

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching client stats.");
        }
    }

    private void deleteSelectedProject() {
        int selectedRow = projectTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a project to delete.");
            return;
        }

        int projectId = (int) projectTable.getValueAt(selectedRow, 0);
        try (Connection con = DatabaseConnection.getConnection()) {
            PreparedStatement pst = con.prepareStatement("DELETE FROM projects WHERE id=?");
            pst.setInt(1, projectId);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Project Deleted Successfully!");
            loadProjects();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
