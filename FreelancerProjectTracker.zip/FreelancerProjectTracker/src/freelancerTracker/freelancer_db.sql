CREATE DATABASE freelancer_db;
USE freelancer_db;

CREATE TABLE credentials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL
);

CREATE TABLE users (
    user_id INT PRIMARY KEY,
    user_name VARCHAR(100),
    phone_number VARCHAR(15),
    email VARCHAR(100),
    gender VARCHAR(10),
    city VARCHAR(50),
    FOREIGN KEY (user_id) REFERENCES credentials(id) ON DELETE CASCADE
);

CREATE TABLE projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100),
    description TEXT,
    assignedTo VARCHAR(50),
    status VARCHAR(50)
);

CREATE TABLE count_of_projects (
    client_id INT PRIMARY KEY AUTO_INCREMENT,
    client_name VARCHAR(100) UNIQUE NOT NULL,
    count_of_accepted INT DEFAULT 0,
    count_of_completed INT DEFAULT 0
);

INSERT INTO users (username, password, role) VALUES ('admin', 'admin123', 'admin');
