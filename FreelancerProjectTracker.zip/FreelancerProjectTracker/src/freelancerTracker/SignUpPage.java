package freelancerTracker;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class SignUpPage extends JFrame {
    private JTextField nameField, phoneField, emailField, cityField, usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> genderBox, roleBox;
    private JButton createButton;

    public SignUpPage() {
        setTitle("Sign Up");
        setSize(400, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(10, 2, 10, 10));

        add(new JLabel("Full Name:"));
        nameField = new JTextField();
        add(nameField);

        add(new JLabel("Phone Number:"));
        phoneField = new JTextField();
        add(phoneField);

        add(new JLabel("Email:"));
        emailField = new JTextField();
        add(emailField);

        add(new JLabel("Gender:"));
        genderBox = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        add(genderBox);

        add(new JLabel("City:"));
        cityField = new JTextField();
        add(cityField);

        add(new JLabel("Username:"));
        usernameField = new JTextField();
        add(usernameField);

        add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        add(passwordField);

        add(new JLabel("Role:"));
        roleBox = new JComboBox<>(new String[]{"Admin", "Client"});
        add(roleBox);

        createButton = new JButton("Create Account");
        add(createButton);

        createButton.addActionListener(e -> createAccount());

        setVisible(true);
    }

    private void createAccount() {
        String name = nameField.getText();
        String phone = phoneField.getText();
        String email = emailField.getText();
        String gender = (String) genderBox.getSelectedItem();
        String city = cityField.getText();
        String username = usernameField.getText();
        String password = String.valueOf(passwordField.getPassword());
        String role = (String) roleBox.getSelectedItem();

        if (name.isEmpty() || phone.isEmpty() || email.isEmpty() || city.isEmpty() || username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.");
            return;
        }

        try (Connection con = DatabaseConnection.getConnection()) {
            // Step 1: Insert into credentials table
            String credentialSQL = "INSERT INTO credentials (username, password, role) VALUES (?, ?, ?)";
            PreparedStatement credStmt = con.prepareStatement(credentialSQL, Statement.RETURN_GENERATED_KEYS);
            credStmt.setString(1, username);
            credStmt.setString(2, password);
            credStmt.setString(3, role);
            credStmt.executeUpdate();

            // Get generated user ID
            ResultSet generatedKeys = credStmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                int userId = generatedKeys.getInt(1);

                // Step 2: Insert into users table
                String userSQL = "INSERT INTO users (user_id, user_name, phone_number, email, gender, city) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement userStmt = con.prepareStatement(userSQL);
                userStmt.setInt(1, userId);
                userStmt.setString(2, name);
                userStmt.setString(3, phone);
                userStmt.setString(4, email);
                userStmt.setString(5, gender);
                userStmt.setString(6, city);
                userStmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Account created successfully!");
                this.dispose(); // Close the signup form
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error creating account. Please try again.");
        }
    }

    public static void main(String[] args) {
        new SignUpPage();
    }
}
